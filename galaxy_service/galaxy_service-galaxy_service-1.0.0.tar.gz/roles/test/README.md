# Test Role

This is a test role for galaxy_service collection.
